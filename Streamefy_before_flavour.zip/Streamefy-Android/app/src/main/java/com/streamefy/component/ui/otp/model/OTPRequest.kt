package com.streamefy.component.ui.otp.model

data class OTPRequest(var fullName:String="",var phoneNumber:String="")
