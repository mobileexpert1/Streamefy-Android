package com.streamefy.component.ui.login.model

data class LoginRequest(
    var email:String="",
    var password:String=""
)