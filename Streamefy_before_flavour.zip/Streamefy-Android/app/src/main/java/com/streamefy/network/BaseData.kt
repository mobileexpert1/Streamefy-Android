package com.streamefy.network
class BaseData<T> {

    var status:Boolean? = null
    var msg:String? = null
    var errors:List<Any>? = null
    var data:T? = null

}