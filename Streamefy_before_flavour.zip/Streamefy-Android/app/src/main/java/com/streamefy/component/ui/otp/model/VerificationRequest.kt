package com.streamefy.component.ui.otp.model

data class VerificationRequest(var phoneNumber:String="",var otp:String="")
