package com.streamefy.component.ui.home.categoryModel

data class CateModel (var title:String="",var subTitle:String="",var image:Int=0,var size:Int=0,var progress:Int=50)