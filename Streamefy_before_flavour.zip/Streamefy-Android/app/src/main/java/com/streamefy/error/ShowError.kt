package com.streamefy.error

import com.streamefy.data.KoinCompo

object ShowError {
    var handleError= KoinCompo.handleError
}