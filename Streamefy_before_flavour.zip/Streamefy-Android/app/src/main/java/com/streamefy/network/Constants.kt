package com.streamefy.network

object Constants {

    const val isLogin = "isLogin"
    const val TOKEN = "Token"

    const val dummy_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0aW1lIjoiVGh1IEp1biAwNiAyMDI0IDA4OjEzOjU4IEdNVCswMDAwIChDb29yZGluYXRlZCBVbml2ZXJzYWwgVGltZSkiLCJweXJlIjoiTmpJNE1EYzVORFV3TWc9PSIsImlhdCI6MTcxNzY2MTYzOH0.l9kdDy79ZkHrwCciM8sOMXKuhqwsPqZRPVfjdO4N_ds"

}