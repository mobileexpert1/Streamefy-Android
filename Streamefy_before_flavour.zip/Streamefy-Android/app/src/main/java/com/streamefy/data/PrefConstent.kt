package com.streamefy.data

object PrefConstent {
    const val TOKEN="token"
    const val REFRESH_TOKEN="refresh_token"
    const val ISLOGIN="isLogin"
    const val PHONE_NUMBER="number"
    const val AUTH_PIN="auth_pin"
    const val FULL_NAME="full_name"
    const val ISAUTH="isauth"
    const val VIDEO_URL="video_url"
    const val SMART_REVISION="isSmartRevision"
    const val PLAY_BACK_DURATION="playBackduration"
    const val APP_LOGO="applogo"
    const val AUTH_BACKGROUND="authbackground"
    const val VIDEO_THUMB="video_thumb"

    const val dummy_token="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiQWRtaW4iLCJuYW1laWQiOiI1NyIsInVuaXF1ZV9uYW1lIjoiTW9iaWxlIiwiZW1haWwiOiJhcHBzZGV2MDk2QGdtYWlsLmNvbSIsIklzU3Vic2NyaXB0aW9uQ2FuY2VsbGVkIjoiZmFsc2UiLCJJc0VuYWJsZWQiOiJGYWxzZSIsIklzUHJvZmlsZUFjdGl2ZSI6ImZhbHNlIiwibmJmIjoxNzI1NjIyODEzLCJleHAiOjE3MjU3MDkyMTMsImlhdCI6MTcyNTYyMjgxM30.NOrIWHJ3pLacQKaa-auSNWAkbwx_-9_YN1L9rpzHCHg"

}