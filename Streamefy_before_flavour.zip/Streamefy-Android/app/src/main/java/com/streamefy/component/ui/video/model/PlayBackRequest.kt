package com.streamefy.component.ui.video.model

data class PlayBackRequest(
    var number:String="",
    var mediaId:Int=0,
    var duration:String="",
)